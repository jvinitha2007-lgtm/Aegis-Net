require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt = require('bcryptjs');
const path = require('path');
const { run, get, all, init } = require('./db');

const app = express();
const PORT = Number(process.env.PORT || 4000);
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';
app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }));
app.use(express.json({ limit: '50kb' }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: path.join(__dirname, 'data') }),
  name: 'aegisnet.sid',
  secret: process.env.SESSION_SECRET || 'development-only-change-me-before-deployment',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 1000 * 60 * 60 * 8 }
}));

const publicUser = u => ({ id: u.id, name: u.name, email: u.email, created_at: u.created_at });
const cleanEmail = email => String(email || '').trim().toLowerCase();
const cleanName = name => String(name || '').trim();
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please sign in to continue.' });
  next();
}
function handleError(res, error) {
  console.error(error);
  res.status(500).json({ error: 'Server error. Check the VS Code backend terminal.' });
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'AegisNet API' }));

app.post('/api/auth/register', async (req, res) => {
  try {
    const name = cleanName(req.body.name), email = cleanEmail(req.body.email), password = String(req.body.password || '');
    if (name.length < 2) return res.status(400).json({ error: 'Name must be at least 2 characters.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
    if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    const existing = await get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) return res.status(409).json({ error: 'An account with this email already exists. Please sign in.' });
    const password_hash = await bcrypt.hash(password, 12);
    const result = await run('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)', [name,email,password_hash]);
    const user = await get('SELECT id,name,email,created_at FROM users WHERE id = ?', [result.id]);
    await run('INSERT INTO alerts (user_id,title,severity,status) VALUES (?,?,?,?)', [user.id,'Welcome to AegisNet demo','Low','Open']);
    req.session.userId = user.id;
    res.status(201).json({ user: publicUser(user) });
  } catch (e) { handleError(res,e); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const email = cleanEmail(req.body.email), password = String(req.body.password || '');
    const user = await get('SELECT * FROM users WHERE email = ?', [email]);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Incorrect email or password.' });
    req.session.userId = user.id;
    res.json({ user: publicUser(user) });
  } catch (e) { handleError(res,e); }
});
app.get('/api/auth/me', async (req,res) => {
  try {
    if (!req.session.userId) return res.status(401).json({ error: 'Not signed in.' });
    const user = await get('SELECT id,name,email,created_at FROM users WHERE id = ?', [req.session.userId]);
    if (!user) return res.status(401).json({ error: 'Account not found.' });
    res.json({ user: publicUser(user) });
  } catch(e) { handleError(res,e); }
});
app.post('/api/auth/logout', (req,res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Could not sign out.' });
    res.clearCookie('aegisnet.sid'); res.json({ ok: true });
  });
});

app.get('/api/events', requireAuth, async (req, res) => {
  try {
    const page = Math.max(1, Math.min(100000, Number.parseInt(req.query.page, 10) || 1));
    const limit = Math.max(10, Math.min(100, Number.parseInt(req.query.limit, 10) || 25));
    const search = String(req.query.search || '').trim().slice(0, 100);
    const severity = String(req.query.severity || '').trim();
    const where = [];
    const params = [];
    if (search) { where.push('(event_code LIKE ? OR event_type LIKE ? OR source_ip LIKE ? OR destination LIKE ? OR description LIKE ?)'); const q = `%${search}%`; params.push(q,q,q,q,q); }
    if (['Low','Medium','High','Critical'].includes(severity)) { where.push('severity = ?'); params.push(severity); }
    const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = await get(`SELECT COUNT(*) AS count FROM threat_events ${clause}`, params);
    const events = await all(`SELECT id,event_code,event_type,source_ip,destination,severity,status,description,created_at FROM threat_events ${clause} ORDER BY id DESC LIMIT ? OFFSET ?`, [...params, limit, (page - 1) * limit]);
    res.json({ events, pagination: { page, limit, total: total.count, pages: Math.ceil(total.count / limit) } });
  } catch (e) { handleError(res, e); }
});

app.get('/api/dashboard', requireAuth, async (req,res) => {
  try {
    const userId = req.session.userId;
    const open = await get("SELECT COUNT(*) AS count FROM alerts WHERE user_id=? AND status='Open'", [userId]);
    const scans = await get('SELECT COUNT(*) AS count FROM scans WHERE user_id=?', [userId]);
    const latest = await get('SELECT score FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 1', [userId]);
    res.json({ summary: { score: latest ? latest.score : 85, devices: 8, openAlerts: open.count, scans: scans.count } });
  } catch(e) { handleError(res,e); }
});
app.get('/api/alerts', requireAuth, async (req,res) => {
  try { res.json({ alerts: await all('SELECT * FROM alerts WHERE user_id=? ORDER BY id DESC LIMIT 200', [req.session.userId]) }); }
  catch(e) { handleError(res,e); }
});
app.patch('/api/alerts/:id/resolve', requireAuth, async (req,res) => {
  try {
    const result = await run("UPDATE alerts SET status='Resolved' WHERE id=? AND user_id=?", [Number(req.params.id),req.session.userId]);
    if (!result.changes) return res.status(404).json({ error: 'Alert not found.' });
    res.json({ alert: await get('SELECT * FROM alerts WHERE id=? AND user_id=?', [Number(req.params.id),req.session.userId]) });
  } catch(e) { handleError(res,e); }
});
app.get('/api/scans', requireAuth, async (req,res) => {
  try { res.json({ scans: await all('SELECT * FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 100', [req.session.userId]) }); }
  catch(e) { handleError(res,e); }
});
app.post('/api/scans', requireAuth, async (req,res) => {
  try {
    // This is intentionally a simulated scan: it does not inspect devices or networks.
    const score = 85 + Math.floor(Math.random() * 13);
    const result = await run('INSERT INTO scans (user_id,status,score,findings) VALUES (?,?,?,?)', [req.session.userId,'Completed (demo)',score,0]);
    const scan = await get('SELECT * FROM scans WHERE id=?', [result.id]);
    const alertResult = await run('INSERT INTO alerts (user_id,title,severity,status) VALUES (?,?,?,?)', [req.session.userId,'Simulated security scan completed','Low','Open']);
    const alert = await get('SELECT * FROM alerts WHERE id=?', [alertResult.id]);
    const open = await get("SELECT COUNT(*) AS count FROM alerts WHERE user_id=? AND status='Open'", [req.session.userId]);
    const scans = await get('SELECT COUNT(*) AS count FROM scans WHERE user_id=?', [req.session.userId]);
    res.status(201).json({ scan, alert, summary: { score, devices: 8, openAlerts: open.count, scans: scans.count } });
  } catch(e) { handleError(res,e); }
});
app.put('/api/profile', requireAuth, async (req,res) => {
  try {
    const name = cleanName(req.body.name), email = cleanEmail(req.body.email);
    if (name.length < 2) return res.status(400).json({ error: 'Name must be at least 2 characters.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
    await run('UPDATE users SET name=?, email=? WHERE id=?', [name,email,req.session.userId]);
    const user = await get('SELECT id,name,email,created_at FROM users WHERE id=?', [req.session.userId]);
    res.json({ user: publicUser(user) });
  } catch(e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'That email is already used by another account.' });
    handleError(res,e);
  }
});

init().then(() => {
  app.listen(PORT, '127.0.0.1', () => console.log(`AegisNet API running at http://localhost:${PORT}`));
}).catch(err => { console.error('Database initialization failed:',err); process.exit(1); });