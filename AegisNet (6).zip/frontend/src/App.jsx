import { useEffect, useMemo, useState } from 'react';
import {
  Activity, AlertTriangle, Bell, Check, ChevronDown, CircleHelp, Download,
  FileText, Gauge, LayoutDashboard, LogOut, Menu, Network, RefreshCw,
  Search, Settings, Shield, ShieldCheck, UserRound, Users, X, Zap, Database
} from 'lucide-react';
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis
} from 'recharts';

const API = 'http://localhost:4000/api';
const navItems = [
  ['Dashboard', LayoutDashboard], ['Security', ShieldCheck], ['Network', Network],
  ['Alerts', Bell], ['Threat Data', Database], ['Reports', FileText], ['Profile', UserRound], ['Settings', Settings]
];
const demoTrend = [
  { day: 'Mon', events: 14 }, { day: 'Tue', events: 22 }, { day: 'Wed', events: 17 },
  { day: 'Thu', events: 31 }, { day: 'Fri', events: 24 }, { day: 'Sat', events: 18 },
  { day: 'Sun', events: 27 }
];

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function AuthScreen({ onAuth }) {
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function submit(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try {
      const result = await request(`/auth/${mode}`, {
        method: 'POST', body: JSON.stringify({ name, email, password })
      });
      onAuth(result.user);
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  return <div className="auth-wrap">
    <div className="auth-card">
      <div className="brand-mark"><ShieldCheck size={30}/></div>
      <p className="eyebrow">A PROTECTIVE NETWORK</p>
      <h1>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
      <p className="muted">Your AegisNet security workspace.</p>
      <form onSubmit={submit} className="auth-form">
        {mode === 'register' && <label>Full name<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" maxLength={80}/></label>}
        <label>Email address<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" maxLength={160}/></label>
        <label>Password<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters" minLength={8}/></label>
        {error && <div className="error-note">{error}</div>}
        <button className="primary-btn full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
      </form>
      <p className="switch-auth">{mode === 'login' ? 'New to AegisNet?' : 'Already have an account?'} <button onClick={()=>{setMode(mode === 'login' ? 'register' : 'login');setError('')}}>{mode === 'login' ? 'Create account' : 'Sign in'}</button></p>
      <p className="tiny muted">Demo project · Passwords are hashed before storage.</p>
    </div>
  </div>;
}

function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  const [page, setPage] = useState('Dashboard');
  const [summary, setSummary] = useState({ score: 85, devices: 8, openAlerts: 2, scans: 0 });
  const [alerts, setAlerts] = useState([]);
  const [scans, setScans] = useState([]);
  const [events, setEvents] = useState([]);
  const [eventPage, setEventPage] = useState(1);
  const [eventPages, setEventPages] = useState(1);
  const [eventTotal, setEventTotal] = useState(15500);
  const [eventSearch, setEventSearch] = useState('');
  const [eventSeverity, setEventSeverity] = useState('');
  const [busyScan, setBusyScan] = useState(false);
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [mobileNav, setMobileNav] = useState(false);
  const [profileName, setProfileName] = useState('');
  const [profileEmail, setProfileEmail] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [settings, setSettings] = useState({ emailAlerts: true, weeklySummary: true });

  async function loadEvents(page = eventPage, search = eventSearch, severity = eventSeverity) {
    const params = new URLSearchParams({ page: String(page), limit: '25' });
    if (search.trim()) params.set('search', search.trim());
    if (severity) params.set('severity', severity);
    const result = await request(`/events?${params.toString()}`);
    setEvents(result.events); setEventPage(result.pagination.page); setEventPages(result.pagination.pages); setEventTotal(result.pagination.total);
  }

  async function loadData() {
    const [s, a, h] = await Promise.all([
      request('/dashboard'), request('/alerts'), request('/scans')
    ]);
    setSummary(s.summary); setAlerts(a.alerts); setScans(h.scans);
  }
  useEffect(() => {
    request('/auth/me').then(({user: u}) => {
      setUser(u); setProfileName(u.name); setProfileEmail(u.email);
      return loadData();
    }).catch(() => {}).finally(() => setChecking(false));
  }, []);
  useEffect(() => {
    if (user && page === 'Threat Data') loadEvents().catch(e => setNotice(e.message));
  }, [user, page, eventPage]);
  useEffect(() => {
    if (!notice) return;
    const id = setTimeout(() => setNotice(''), 3500);
    return () => clearTimeout(id);
  }, [notice]);
  const filteredAlerts = useMemo(() => alerts.filter(a =>
    `${a.title} ${a.severity} ${a.status}`.toLowerCase().includes(query.toLowerCase())
  ), [alerts, query]);

  async function runScan() {
    setBusyScan(true); setNotice('Running a simulated security scan…');
    try {
      const result = await request('/scans', { method: 'POST', body: JSON.stringify({}) });
      setSummary(result.summary); setScans(old => [result.scan, ...old]);
      setAlerts(old => [result.alert, ...old]);
      setPage('Security'); setNotice('Demo scan completed. No real devices were scanned.');
    } catch (e) { setNotice(e.message); }
    finally { setBusyScan(false); }
  }
  async function resolveAlert(id) {
    try {
      const result = await request(`/alerts/${id}/resolve`, { method: 'PATCH', body: JSON.stringify({}) });
      setAlerts(old => old.map(a => a.id === id ? result.alert : a));
      await loadData(); setNotice('Alert marked as resolved.');
    } catch(e) { setNotice(e.message); }
  }
  async function saveProfile(e) {
    e.preventDefault(); setSavingProfile(true);
    try {
      const result = await request('/profile', { method: 'PUT', body: JSON.stringify({ name: profileName, email: profileEmail }) });
      setUser(result.user); setNotice('Profile updated successfully.');
    } catch(e) { setNotice(e.message); }
    finally { setSavingProfile(false); }
  }
  async function logout() {
    try { await request('/auth/logout', { method: 'POST', body: JSON.stringify({}) }); } catch {}
    setUser(null); setPage('Dashboard');
  }
  function downloadCSV() {
    const rows = [['ID','Title','Severity','Status','Created'], ...alerts.map(a => [a.id,a.title,a.severity,a.status,a.created_at])];
    const csv = rows.map(row => row.map(v => `"${String(v ?? '').replaceAll('"','""')}"`).join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8;'}));
    link.download = 'aegisnet-alert-report.csv'; link.click(); URL.revokeObjectURL(link.href);
    setNotice('CSV report downloaded.');
  }

  if (checking) return <div className="loading-screen"><ShieldCheck size={32}/> Loading AegisNet…</div>;
  if (!user) return <AuthScreen onAuth={u=>{setUser(u);setProfileName(u.name);setProfileEmail(u.email);loadData().catch(e=>setNotice(e.message));}}/>;

  const currentNav = navItems.find(n => n[0] === page);
  const Icon = currentNav ? currentNav[1] : LayoutDashboard;
  const severityClass = s => `severity ${String(s || '').toLowerCase()}`;
  const pageTitle = {
    Dashboard: 'Security overview', Security: 'Security center', Network: 'Network overview',
    Alerts: 'Security alerts', 'Threat Data': 'Threat intelligence dataset', Reports: 'Reports & history', Profile: 'Your profile', Settings: 'Workspace settings'
  }[page] || page;

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'mobile-open' : ''}`}>
      <div className="brand"><div className="brand-icon"><ShieldCheck size={23}/></div><div><strong>AegisNet</strong><small>A PROTECTIVE NETWORK</small></div><button className="close-nav icon-btn" onClick={()=>setMobileNav(false)} aria-label="Close menu"><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{navItems.map(([label, NavIcon])=><button key={label} className={`nav-link ${page===label?'selected':''}`} onClick={()=>{setPage(label);setMobileNav(false)}}><NavIcon size={18}/><span>{label}</span>{label==='Alerts' && summary.openAlerts>0 && <em>{summary.openAlerts}</em>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="secure-badge"><Shield size={17}/><div><strong>Demo protection</strong><small>Simulated monitoring</small></div></div><button className="nav-link logout" onClick={logout}><LogOut size={18}/>Sign out</button></div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={()=>setMobileNav(true)} aria-label="Open menu"><Menu size={21}/></button>
        <div className="breadcrumbs"><span>Workspace</span><span className="slash">/</span><strong>{page}</strong></div>
        <div className="top-actions"><div className="live-pill"><span/> Demo environment</div><button className="icon-btn" title="Refresh dashboard" onClick={()=>loadData().then(()=>setNotice('Dashboard refreshed.')).catch(e=>setNotice(e.message))}><RefreshCw size={17}/></button><div className="user-chip"><div className="avatar">{(user.name||'A').charAt(0).toUpperCase()}</div><div><strong>{user.name}</strong><small>Administrator</small></div><ChevronDown size={15}/></div></div>
      </header>

      <div className="page-content">
        <section className="page-heading">
          <div><p className="eyebrow">CYBERSECURITY CONTROL CENTER</p><h1><Icon size={27}/>{pageTitle}</h1><p className="muted">Monitor activity, review events, and manage your security workspace.</p></div>
          <button className="primary-btn" onClick={runScan} disabled={busyScan}><Zap size={17}/>{busyScan?'Scanning…':'Run demo scan'}</button>
        </section>
        {notice && <div className="toast" role="status"><Check size={17}/>{notice}<button onClick={()=>setNotice('')} aria-label="Dismiss"><X size={16}/></button></div>}

        {page === 'Dashboard' && <>
          <div className="stats-grid">
            <Stat icon={ShieldCheck} label="Security score" value={`${summary.score}/100`} sub="Demo calculation" color="blue"/>
            <Stat icon={Network} label="Monitored assets" value={summary.devices} sub="Sample assets" color="purple"/>
            <Stat icon={AlertTriangle} label="Open alerts" value={summary.openAlerts} sub="Requires review" color="orange"/>
            <Stat icon={Activity} label="Scans completed" value={summary.scans} sub="Saved in database" color="green"/>
          </div>
          <div className="two-col">
            <section className="panel">
              <div className="panel-heading"><div><h2>Activity overview</h2><p className="muted">Illustrative weekly event volume</p></div><span className="tag">DEMO DATA</span></div>
              <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={demoTrend} margin={{top:10,right:8,left:-20,bottom:0}}><defs><linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4d9fff" stopOpacity={0.35}/><stop offset="95%" stopColor="#4d9fff" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#26324a" strokeDasharray="3 3" vertical={false}/><XAxis dataKey="day" stroke="#71809c" tickLine={false} axisLine={false}/><YAxis stroke="#71809c" tickLine={false} axisLine={false}/><Tooltip contentStyle={{background:'#111b2f',border:'1px solid #2a3b58',borderRadius:10,color:'#fff'}}/><Area type="monotone" dataKey="events" stroke="#58a8ff" strokeWidth={2.5} fill="url(#areaFill)"/></AreaChart></ResponsiveContainer></div>
            </section>
            <section className="panel">
              <div className="panel-heading"><div><h2>System status</h2><p className="muted">Application component status</p></div><Gauge color="#4fddb0"/></div>
              <StatusRow label="Frontend" value="Online" good/><StatusRow label="API server" value="Connected" good/><StatusRow label="SQLite database" value="Connected" good/><StatusRow label="Real network monitoring" value="Not configured" />
              <div className="info-box"><CircleHelp size={16}/><span>Scores and monitoring data are demo indicators, not a real security assessment.</span></div>
            </section>
          </div>
          <AlertsTable alerts={alerts.slice(0,5)} onResolve={resolveAlert} onView={()=>setPage('Alerts')}/>
        </>}

        {page === 'Security' && <div className="stack">
          <div className="stats-grid two-stats"><Stat icon={ShieldCheck} label="Current demo score" value={`${summary.score}/100`} sub="Illustrative only" color="blue"/><Stat icon={Activity} label="Scans in history" value={scans.length} sub="Persisted scan records" color="green"/></div>
          <section className="panel"><div className="panel-heading"><div><h2>Security scan center</h2><p className="muted">Run a safe simulated scan and save the result.</p></div><button className="primary-btn" onClick={runScan} disabled={busyScan}><Zap size={16}/>{busyScan?'Scanning…':'Start demo scan'}</button></div><div className="info-box"><AlertTriangle size={17}/><span>This scan generates sample findings only. It does not scan your computer or any external network.</span></div><div className="table-wrap"><table><thead><tr><th>Scan ID</th><th>Result</th><th>Score</th><th>Time</th></tr></thead><tbody>{scans.length?scans.map(s=><tr key={s.id}><td>#{s.id}</td><td><span className="severity normal">{s.status}</span></td><td>{s.score}/100</td><td>{new Date(s.created_at).toLocaleString()}</td></tr>):<EmptyRow text="No scans yet. Run a demo scan to create a record." cols={4}/>}</tbody></table></div></section>
        </div>}

        {page === 'Network' && <div className="stack"><div className="stats-grid"><Stat icon={Network} label="Sample assets" value={summary.devices} sub="Illustrative count" color="purple"/><Stat icon={Activity} label="Connection status" value="Local demo" sub="No network scan performed" color="blue"/><Stat icon={ShieldCheck} label="Monitoring" value="Not configured" sub="Integration required" color="green"/><Stat icon={Users} label="Active users" value="1" sub="Current workspace session" color="orange"/></div><section className="panel"><div className="panel-heading"><div><h2>Asset inventory</h2><p className="muted">Example entries for the project demonstration</p></div><span className="tag">SAMPLE</span></div><div className="table-wrap"><table><thead><tr><th>Asset</th><th>Type</th><th>Status</th><th>Last checked</th></tr></thead><tbody>{[['Gateway-01','Gateway','Online'],['Workstation-02','Workstation','Sample'],['Database-01','Database','Online'],['Endpoint-04','Endpoint','Sample']].map((r,i)=><tr key={r[0]}><td><div className="asset-name"><Network size={16}/>{r[0]}</div></td><td>{r[1]}</td><td><span className={`severity ${i===1||i===3?'medium':'normal'}`}>{r[2]}</span></td><td>Demo data</td></tr>)}</tbody></table></div></section></div>}

        {page === 'Alerts' && <section className="panel"><div className="panel-heading"><div><h2>Security alerts</h2><p className="muted">Search, review, and resolve stored alert records.</p></div><span className="tag">{filteredAlerts.length} EVENTS</span></div><div className="table-tools"><div className="search-box"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search alerts…"/></div><button className="secondary-btn" onClick={()=>loadData().catch(e=>setNotice(e.message))}><RefreshCw size={15}/>Refresh</button></div><AlertsTable alerts={filteredAlerts} onResolve={resolveAlert}/></section>}

        {page === 'Threat Data' && <section className="panel"><div className="panel-heading"><div><h2>Threat event dataset</h2><p className="muted">15,500 synthetic cybersecurity records stored in SQLite; use search and filters to browse.</p></div><span className="tag">{eventTotal.toLocaleString()} RECORDS</span></div><div className="table-tools"><div className="search-box"><Search size={16}/><input value={eventSearch} onChange={e=>setEventSearch(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')loadEvents(1,eventSearch,eventSeverity).catch(err=>setNotice(err.message))}} placeholder="Search event, IP, destination…"/></div><select value={eventSeverity} onChange={e=>{setEventSeverity(e.target.value);loadEvents(1,eventSearch,e.target.value).catch(err=>setNotice(err.message))}} className="event-filter"><option value="">All severities</option><option>Low</option><option>Medium</option><option>High</option><option>Critical</option></select><button className="secondary-btn" onClick={()=>loadEvents(1,eventSearch,eventSeverity).catch(e=>setNotice(e.message))}><Search size={15}/>Search</button></div><div className="table-wrap"><table><thead><tr><th>Event ID</th><th>Event type</th><th>Source IP</th><th>Destination</th><th>Severity</th><th>Status</th><th>Date</th></tr></thead><tbody>{events.length?events.map(ev=><tr key={ev.id}><td><strong>{ev.event_code}</strong></td><td>{ev.event_type}</td><td>{ev.source_ip}</td><td>{ev.destination}</td><td><span className={`severity ${ev.severity.toLowerCase()}`}>{ev.severity}</span></td><td>{ev.status}</td><td>{new Date(ev.created_at).toLocaleDateString()}</td></tr>):<EmptyRow text="No matching events found." cols={7}/>}</tbody></table></div><div className="event-pagination"><span>Showing page {eventPage} of {Math.max(1,eventPages)} · {eventTotal.toLocaleString()} records</span><div><button className="secondary-btn" disabled={eventPage<=1} onClick={()=>{const p=eventPage-1;setEventPage(p);loadEvents(p,eventSearch,eventSeverity).catch(e=>setNotice(e.message))}}>Previous</button><button className="secondary-btn" disabled={eventPage>=eventPages} onClick={()=>{const p=eventPage+1;setEventPage(p);loadEvents(p,eventSearch,eventSeverity).catch(e=>setNotice(e.message))}}>Next</button></div></div></section>}

        {page === 'Reports' && <div className="stack"><section className="panel"><div className="panel-heading"><div><h2>Reports & history</h2><p className="muted">Export alerts or review scan history.</p></div><button className="primary-btn" onClick={downloadCSV}><Download size={16}/>Download alerts CSV</button></div><div className="stats-grid two-stats report-stats"><Stat icon={Bell} label="Total alerts" value={alerts.length} sub="Saved records" color="orange"/><Stat icon={FileText} label="Scan records" value={scans.length} sub="Saved records" color="blue"/></div><div className="table-wrap"><table><thead><tr><th>Scan</th><th>Status</th><th>Score</th><th>Date</th></tr></thead><tbody>{scans.length?scans.map(s=><tr key={s.id}><td>Scan #{s.id}</td><td>{s.status}</td><td>{s.score}/100</td><td>{new Date(s.created_at).toLocaleString()}</td></tr>):<EmptyRow text="No scan records yet." cols={4}/>}</tbody></table></div></section></div>}

        {page === 'Profile' && <section className="panel form-panel"><div className="panel-heading"><div><h2>Profile details</h2><p className="muted">Changes are saved to the SQLite database.</p></div><div className="large-avatar">{(profileName||'A').charAt(0).toUpperCase()}</div></div><form className="profile-form" onSubmit={saveProfile}><label>Display name<input required maxLength={80} value={profileName} onChange={e=>setProfileName(e.target.value)}/></label><label>Email address<input required type="email" maxLength={160} value={profileEmail} onChange={e=>setProfileEmail(e.target.value)}/></label><button className="primary-btn" disabled={savingProfile}>{savingProfile?'Saving…':'Save profile'}</button></form></section>}

        {page === 'Settings' && <section className="panel"><div className="panel-heading"><div><h2>Workspace settings</h2><p className="muted">These notification preferences are stored for this browser session.</p></div><Settings color="#60a5fa"/></div><div className="setting-row"><div><strong>Email alert preference</strong><p className="muted">Demo toggle only; no email is sent.</p></div><button className={`toggle ${settings.emailAlerts?'on':''}`} onClick={()=>setSettings(s=>({...s,emailAlerts:!s.emailAlerts}))} aria-pressed={settings.emailAlerts}><span/></button></div><div className="setting-row"><div><strong>Weekly summary</strong><p className="muted">Demo preference only; no scheduled report is sent.</p></div><button className={`toggle ${settings.weeklySummary?'on':''}`} onClick={()=>setSettings(s=>({...s,weeklySummary:!s.weeklySummary}))} aria-pressed={settings.weeklySummary}><span/></button></div><div className="info-box"><CircleHelp size={16}/><span>For production use, add server-side storage for preferences and a real notification service.</span></div></section>}
        <footer className="footer">AEGISNET © 2026 <span>·</span> A PROTECTIVE NETWORK <span>·</span> DEMO ENVIRONMENT</footer>
      </div>
    </main>
  </div>;
}

function Stat({icon: Icon, label, value, sub, color}) {
  return <div className="stat-card"><div className={`stat-icon ${color}`}><Icon size={20}/></div><p>{label}</p><h3>{value}</h3><span className="stat-sub">{sub}</span></div>;
}
function StatusRow({label,value,good=false}) {
  return <div className="status-row"><span>{label}</span><strong className={good?'good':''}><i/>{value}</strong></div>;
}
function EmptyRow({text,cols}) { return <tr><td colSpan={cols} className="empty-cell">{text}</td></tr>; }
function AlertsTable({alerts,onResolve,onView}) {
  return <section className="panel alerts-panel"><div className="panel-heading"><div><h2>Recent alerts</h2><p className="muted">Latest stored events</p></div>{onView&&<button className="text-btn" onClick={onView}>View all →</button>}</div><div className="table-wrap"><table><thead><tr><th>Event</th><th>Severity</th><th>Status</th><th>Created</th><th>Action</th></tr></thead><tbody>{alerts.length?alerts.map(a=><tr key={a.id}><td><div className="event-title"><span className="event-icon"><AlertTriangle size={16}/></span><strong>{a.title}</strong></div></td><td><span className={severityClassSafe(a.severity)}>{a.severity}</span></td><td><span className={`status-text ${a.status==='Resolved'?'resolved':''}`}>{a.status}</span></td><td>{a.created_at ? new Date(a.created_at).toLocaleString() : 'Just now'}</td><td>{a.status!=='Resolved'?<button className="small-btn" onClick={()=>onResolve(a.id)}>Resolve</button>:<span className="muted">Done</span>}</td></tr>):<EmptyRow text="No alerts match your search." cols={5}/>}</tbody></table></div><p className="table-footnote">Events in this student project are demo data, not verified threat detections.</p></section>;
}
function severityClassSafe(s) { return `severity ${String(s||'').toLowerCase()}`; }

export default App;
