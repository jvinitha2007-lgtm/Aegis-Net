# AegisNet — A Protective Network

Responsive full-stack cybersecurity awareness/demo dashboard built with React + Vite, Express, and SQLite.

## Features
- Responsive desktop/tablet/mobile dashboard and sidebar
- Registration and login with bcrypt password hashing and SQLite-backed sessions
- Profile updates saved in the database
- Dashboard metrics, simulated scan history, alert management, CSV export
- Threat Data page backed by **15,500 generated synthetic cybersecurity event records** in SQLite
- Threat event search, severity filter, server-side pagination (25 rows per page)
- REST API health endpoint

## Requirements
- Node.js 20+ (Node.js 24 should also work)
- npm

## Run in VS Code
Open this root folder (the one containing `package.json`, `frontend`, and `backend`) in VS Code. Open Terminal and run:

```bash
npm install
npm install --prefix frontend
npm install --prefix backend
npm run dev
```

Open `http://localhost:5173`. The API runs at `http://localhost:4000`; health check: `http://localhost:4000/api/health`.

The first backend start creates `backend/data/aegisnet.sqlite` and seeds 15,500 synthetic event rows. This may take a few seconds. If the seed is interrupted, restart the backend; it fills the remaining rows.

## Main API routes
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `POST /api/auth/logout`
- `GET /api/dashboard`
- `GET /api/alerts`, `PATCH /api/alerts/:id/resolve`
- `GET /api/scans`, `POST /api/scans`
- `GET /api/events?page=1&limit=25&search=...&severity=High`
- `PUT /api/profile`

## Important safety note
This is an educational demo. The 15,500 threat records are synthetic sample data, not real incident intelligence. The “security scan” is simulated and does not inspect devices or scan networks. Real-world monitoring would require authorized integrations, deployment hardening, secure secrets, HTTPS, rate limiting, CSRF protections, and production session storage.
